// For the implementation of three different PDA machines.
//
// Modified by <your-name-here>
//

#include "pda.h"

struct list_node *list = NULL;

int PDA1 (char *str) {

    enum state state = S0; // set the starting state
    // enum state accepting_state = ???; // set the accepting state

    // initialize the stack to NULL
    struct stack_node *stack = NULL;

    /** Implement the first push down automata. **/

    return 0;
}

int PDA2 (char *str) {

    enum state state = S0; // set the starting state
    // enum state accepting_state = ???; // set the accepting state

    // initialize the stack to NULL
    struct stack_node *stack = NULL;

    /** Implement the second push down automata. **/

    return 0;
}

int PDA3 (char *str) {

    /** Implement the third push down automata. **/

    return 0;
}
